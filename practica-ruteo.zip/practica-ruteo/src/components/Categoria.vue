<template>
    <div id="Categoria">
        <p id="titulo">sobre: {{ $route.params.nombrecategoria }}</p>
        <p>No tenemos información sobre esta categoria en este momento</p>
        <img id="comida" alt="dibujo" src="./comida.jpg">
    </div>
</template>

<script>
    export default {
        name: 'Categoria'
    }
</script>

<style scoped>
    #titulo{
        font-size:40px;
    }
    p{
        font-family:calibri;
    }
    #comida{
        display:block;
        width:400px;
        height:300px;
        margin:30px;
    }
</style>