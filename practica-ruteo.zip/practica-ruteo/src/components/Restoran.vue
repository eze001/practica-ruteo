<template>
    <div id="Restoran">
        <p id="titulo">sobre: {{ $route.params.nombrerestoran }}</p>
        <p>No tenemos información sobre este restoran en este momento</p>
        <img id="dibujorestoran" src="./restoran.jpg" alt="dibujo">
    </div>
</template>

<script>
    export default {
        name: 'Restoran'
    }
</script>

<style scoped>
    #titulo{
        font-size:40px;
    }
    p{
        font-family:calibri;
    }
    #dibujorestoran{
        margin:30px;
        width:400px;
        height:300px;
        display:block;
    }
</style>